package com.lms.caller

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.telecom.TelecomManager

/** Collects GPS/network fixes and keeps the most accurate one. Location permission must already be granted. */
class Gps(ctx: Context, private val onFix: (Location) -> Unit) {
    private val lm = ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    var best: Location? = null
        private set
    private var running = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val b = best
            if (b == null || location.accuracy <= b.accuracy || location.time - b.time > 15000L) {
                best = location
                Repo.lastLat = location.latitude
                Repo.lastLng = location.longitude
                Repo.hasFix = true
                onFix(location)
            }
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        best = null
        var ok = false
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000L, 0f, listener, Looper.getMainLooper())
                    ok = true
                }
            } catch (e: Exception) {
            }
        }
        running = ok
        return ok
    }

    fun stop() {
        try { lm.removeUpdates(listener) } catch (e: Exception) { }
        running = false
    }

    val isRunning: Boolean get() = running
}

/** Phone call and navigation helpers shared by every screen. */
object Act {
    private var lastCallAt = 0L

    fun call(h: HomeActivity, phone: String) {
        val n = normalizePhone(phone)
        if (n.isEmpty()) { h.toast("No phone number for this customer"); return }
        if (!Repo.can("call-request")) { h.toast("You do not have permission to call"); return }
        val now = System.currentTimeMillis()
        if (now - lastCallAt < 6000L) return          // ignore double taps: never place two calls
        lastCallAt = now
        val valid = Regex("^01\\d{9}$").matches(n)
        h.needCall { granted ->
            if (granted && valid) {
                try {
                    h.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle())
                } catch (e: Exception) {
                    h.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", n, null)))
                }
            } else {
                h.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", n, null)))
            }
        }
    }

    fun navigate(h: HomeActivity, lat: Double, lng: Double, label: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lng&mode=d"))
            i.setPackage("com.google.android.apps.maps")
            h.startActivity(i)
        } catch (e: Exception) {
            try {
                h.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")))
            } catch (e2: Exception) {
                h.toast("No map app found")
            }
        }
    }

    /** Opens Google Maps with all stops (first stop = nearest, last stop = destination). */
    fun navigateRoute(h: HomeActivity, pts: List<Pair<Double, Double>>) {
        if (pts.isEmpty()) return
        val dest = pts.last()
        val sb = StringBuilder("https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=${dest.first},${dest.second}")
        if (pts.size > 1) {
            sb.append("&waypoints=")
            sb.append(pts.dropLast(1).joinToString("%7C") { "${it.first},${it.second}" })
        }
        try {
            h.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sb.toString())))
        } catch (e: Exception) {
            h.toast("No map app found")
        }
    }
}
