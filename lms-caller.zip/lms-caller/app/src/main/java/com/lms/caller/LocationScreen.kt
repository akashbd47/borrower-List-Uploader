package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

object MapStyle {
    const val STREET = "https://tiles.openfreemap.org/styles/liberty"
    private const val SAT = "{\"version\":8," +
        "\"glyphs\":\"https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf\"," +
        "\"sources\":{\"sat\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"]," +
        "\"tileSize\":256,\"maxzoom\":19,\"attribution\":\"Esri, Maxar, Earthstar Geographics\"}}," +
        "\"layers\":[{\"id\":\"sat\",\"type\":\"raster\",\"source\":\"sat\"}]}"

    fun font(sat: Boolean): String = if (sat) "Open Sans Regular" else "Noto Sans Regular"

    fun apply(map: MapLibreMap, sat: Boolean, done: (Style) -> Unit) {
        val b = if (sat) Style.Builder().fromJson(SAT) else Style.Builder().fromUri(STREET)
        map.setStyle(b) { style -> done(style) }
    }
}

/** Location tab: pick a customer, then set the home pin. The Update button syncs CustomerLocations with LoanMonthlyData. */
class LocationScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Customer Location", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search customer name")
    private val count = h.label("", 12f, C.muted)
    private val list = CustList(h, 1) { LocationEditor.open(h, it) }
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private var onlyMissing = false
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        root.setBackgroundColor(C.bg)
        header.action(h, R.drawable.ic_sync) { runUpdate() }
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val box = h.vbox()
        box.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(4))
        box.addView(search.root)

        val row = h.hbox()
        unionBar = UnionBar(h) { refreshList() }
        row.addView(unionBar.root)
        val tg = h.label("Without location", 13f, C.muted, true)
        tg.setPadding(h.dp(14), h.dp(8), h.dp(14), h.dp(8))
        tg.isClickable = true
        fun paint() {
            tg.setTextColor(if (onlyMissing) Color.WHITE else C.primary)
            tg.background = h.shape(if (onlyMissing) C.warn else Color.WHITE, 20, if (onlyMissing) C.warn else C.line)
        }
        tg.setOnClickListener { onlyMissing = !onlyMissing; paint(); refreshList() }
        paint()
        row.addView(tg, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
        box.addView(row, h.lp(10))
        box.addView(count, h.lp(8))
        root.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !c.sName.contains(q) && !c.sFather.contains(q) && !c.sSpouse.contains(q) &&
                !c.sPhone.contains(q.filter { it in '0'..'9' }.ifEmpty { "\u0000" })) continue
            if (onlyMissing && Repo.locFor(c) != null) continue
            out.add(c)
        }
        out.sortBy { it.sName }
        count.text = "${out.size} customers  \u2022  ${Repo.locs.size} locations saved"
        list.submit(out)
    }

    /** Update button: preview first, write only the changed locations. */
    private fun runUpdate() {
        if (Repo.loans.isEmpty()) { h.toast("Customer data is not loaded yet"); return }
        val plan = Repo.planSync()
        val msg = StringBuilder()
        msg.append("Phone number updated: ").append(plan.phone).append('\n')
        msg.append("Loan programme / case updated: ").append(plan.loan).append('\n')
        msg.append("Name, village, union refreshed: ").append(plan.info).append('\n')
        msg.append("Loan closed (not in loan data): ").append(plan.inactive).append('\n')
        msg.append("Need your review: ").append(plan.review.size).append('\n')
        msg.append("No change: ").append(plan.unchanged)
        val b = AlertDialog.Builder(h).setTitle("Update locations").setMessage(msg.toString())
        if (plan.items.isNotEmpty()) {
            b.setPositiveButton("Update now") { _, _ ->
                h.toast("Updating...")
                Repo.applySync(plan) { ok, m -> h.toast(if (ok) m else "Failed: $m") }
            }
        }
        if (plan.review.isNotEmpty()) {
            b.setNeutralButton("Review list") { _, _ -> showReview(plan) }
        }
        b.setNegativeButton("Close", null)
        b.show()
    }

    private fun showReview(plan: SyncPlan) {
        val lines = plan.review.take(40).joinToString("\n\n") { (l, why) ->
            "${l.name}\n${l.village}  ${l.phone}\n$why"
        }
        AlertDialog.Builder(h).setTitle("Need review (${plan.review.size})")
            .setMessage(lines + if (plan.review.size > 40) "\n\n..." else "")
            .setPositiveButton("OK", null).show()
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Set / update the home pin of one customer. The red target stays in the middle; move the map under it. */
class LocationEditor private constructor(private val h: HomeActivity, private val c: Cust) {
    val root = h.vbox()
    private val mv = MapView(h)
    private var map: MapLibreMap? = null
    private var sat = false
    private var moved = false
    private var gps: Gps? = null
    private var gpsFix: Location? = null
    private val handler = Handler(Looper.getMainLooper())
    private val gpsText: TextView = h.label("GPS not started", 13f, C.muted)
    private val existing: Loc? = Repo.locFor(c)

    companion object {
        fun open(h: HomeActivity, c: Cust) {
            val e = LocationEditor(h, c)
            h.push(e.root) { e.close() }
            e.start()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        val hd = Header(h, if (existing != null) "Update location" else "Add location",
            listOf(c.name, c.village).filter { it.isNotEmpty() }.joinToString("  \u2022  "), { h.pop() })
        root.addView(hd.root)

        val mapBox = FrameLayout(h)
        mapBox.addView(mv, FrameLayout.LayoutParams(MATCH, MATCH))
        val target = h.icon(R.drawable.ic_target, C.bad, 36)
        mapBox.addView(target, FrameLayout.LayoutParams(h.dp(36), h.dp(36), Gravity.CENTER))
        val tip = h.label("Move the map so the red target is exactly on the house", 12f, C.text, true)
        tip.background = h.shape(Color.WHITE, 12)
        tip.setPadding(h.dp(12), h.dp(8), h.dp(12), h.dp(8))
        tip.elevation = h.dp(3).toFloat()
        mapBox.addView(tip, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            setMargins(h.dp(10), h.dp(10), h.dp(70), 0)
        })
        val satBtn = h.fab(R.drawable.ic_layers) { toggleSat() }
        mapBox.addView(satBtn, FrameLayout.LayoutParams(h.dp(46), h.dp(46), Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(10), h.dp(10), 0)
        })
        root.addView(mapBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = h.vbox()
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(14))
        bottom.elevation = h.dp(8).toFloat()
        if (existing != null) {
            bottom.addView(h.label("Already saved by ${existing.updatedBy} on ${fmtDate(existing.updatedAt)}", 12f, C.muted))
        }
        bottom.addView(gpsText, h.lp(4))
        val row = h.hbox()
        row.addView(h.btn("Use GPS", 1, R.drawable.ic_target) { startGps() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(8) })
        row.addView(h.btn("Save location", 0, R.drawable.ic_pin) { save() }, LinearLayout.LayoutParams(0, WRAP, 1.3f))
        bottom.addView(row, h.lp(10))
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun start() {
        h.registerMap(mv)
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isRotateGesturesEnabled = false
            m.uiSettings.isCompassEnabled = false
            val e = existing
            val cam = when {
                e != null -> CameraPosition.Builder().target(LatLng(e.lat, e.lng)).zoom(18.0).build()
                Repo.hasFix -> CameraPosition.Builder().target(LatLng(Repo.lastLat, Repo.lastLng)).zoom(17.0).build()
                else -> villageCenter()
            }
            m.cameraPosition = cam
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) moved = true
            }
            MapStyle.apply(m, false) { }
        }
        if (existing == null) startGps()
    }

    /** Centre on other saved pins of the same village (if any) so the map opens near the right place. */
    private fun villageCenter(): CameraPosition {
        val same = Repo.locs.values.filter { it.village.isNotEmpty() && it.village == c.village }
        if (same.isNotEmpty()) {
            return CameraPosition.Builder()
                .target(LatLng(same.map { it.lat }.average(), same.map { it.lng }.average())).zoom(15.0).build()
        }
        return CameraPosition.Builder().target(LatLng(23.7, 90.4)).zoom(6.0).build()
    }

    private fun toggleSat() {
        val m = map ?: return
        sat = !sat
        MapStyle.apply(m, sat) { }
    }

    private fun startGps() {
        h.needLocation { ok ->
            if (!ok) {
                h.toast("Location permission is needed to use GPS")
            } else {
                moved = false
                var g = gps
                if (g == null) {
                    g = Gps(h) { onFix(it) }
                    gps = g
                }
                if (g.start()) {
                    gpsText.setTextColor(C.muted)
                    gpsText.text = "Searching GPS... stay outside near the house"
                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({ stopGps("GPS stopped") }, 45000L)
                } else {
                    gpsText.setTextColor(C.bad)
                    gpsText.text = "Location is turned off. Turn on GPS in phone settings."
                }
            }
        }
    }

    private fun stopGps(msg: String) {
        val g = gps ?: return
        if (!g.isRunning) return
        g.stop()
        val f = gpsFix
        if (f != null) gpsText.text = "$msg  \u2022  best accuracy \u00B1${f.accuracy.toInt()} m"
    }

    private fun onFix(l: Location) {
        gpsFix = l
        val a = l.accuracy.toInt()
        gpsText.setTextColor(if (a <= 20) C.ok else if (a <= 50) C.warn else C.bad)
        gpsText.text = "GPS accuracy \u00B1$a m" + if (a <= 20) "  (good)" else "  (improving...)"
        val m = map
        if (m != null && !moved) m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(l.latitude, l.longitude), 18.0))
        if (a <= 12) {
            handler.removeCallbacksAndMessages(null)
            stopGps("GPS fixed")
        }
    }

    private fun save() {
        val m = map
        if (m == null) { h.toast("Map is still loading"); return }
        val t = m.cameraPosition.target
        if (t == null) { h.toast("Map is still loading"); return }
        val fix = gpsFix
        val nearFix = fix != null && distM(fix.latitude, fix.longitude, t.latitude, t.longitude) < 15.0
        if (!nearFix && m.cameraPosition.zoom < 15.0) {
            h.toast("Zoom in and place the target exactly on the house")
            return
        }
        val acc = if (fix != null && nearFix) fix.accuracy.toDouble() else 0.0
        val source = if (nearFix) "gps" else "manual"
        val doSave = {
            Repo.saveLocation(c, existing, t.latitude, t.longitude, acc, source)
            h.toast("Location saved")
            h.pop()
        }
        val weak = nearFix && acc > 50.0
        val replace = existing != null
        val check = {
            if (weak) {
                confirm("GPS is weak (\u00B1${acc.toInt()} m). Save anyway?", doSave)
            } else {
                doSave()
            }
        }
        if (replace) {
            val e = existing!!
            confirm("This customer already has a location (saved by ${e.updatedBy}, ${fmtDate(e.updatedAt)}). Replace it?", check)
        } else {
            check()
        }
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(h).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> yes() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun close() {
        handler.removeCallbacksAndMessages(null)
        gps?.stop()
        h.unregisterMap(mv)
    }
}
