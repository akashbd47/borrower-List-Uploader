package com.lms.caller

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object C {
    val primary = Color.parseColor("#1D4ED8")
    val dark = Color.parseColor("#1E3A8A")
    val bg = Color.parseColor("#F1F5F9")
    val text = Color.parseColor("#0F172A")
    val muted = Color.parseColor("#64748B")
    val ok = Color.parseColor("#16A34A")
    val bad = Color.parseColor("#DC2626")
    val warn = Color.parseColor("#D97706")
    val line = Color.parseColor("#E2E8F0")
    val soft = Color.parseColor("#EFF6FF")
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radius).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.ripple(base: GradientDrawable, radius: Int): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Color.parseColor("#22000000")), base, shape(Color.WHITE, radius))

fun Context.lp(top: Int = 0, w: Int = MATCH, h: Int = WRAP): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

fun Context.vbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.label(t: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.icon(res: Int, tint: Int = C.primary, size: Int = 24): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
}

fun Context.card(): LinearLayout = vbox().apply {
    background = shape(Color.WHITE, 16, C.line)
    setPadding(dp(16), dp(14), dp(16), dp(14))
    elevation = dp(1).toFloat()
}

fun Context.pill(t: String, color: Int, filled: Boolean = false): TextView = TextView(this).apply {
    text = t
    textSize = 12f
    setTypeface(typeface, Typeface.BOLD)
    if (filled) {
        setTextColor(Color.WHITE)
        background = shape(color, 20)
    } else {
        setTextColor(color)
        background = shape((color and 0xFFFFFF) or 0x1F000000, 20)
    }
    setPadding(dp(10), dp(4), dp(10), dp(4))
}

/** kind: 0 = primary, 1 = outline, 2 = danger outline, 3 = soft */
fun Context.btn(t: String, kind: Int = 0, iconRes: Int = 0, onClick: () -> Unit): LinearLayout {
    val row = hbox()
    row.gravity = Gravity.CENTER
    val fg = when (kind) {
        0 -> Color.WHITE
        2 -> C.bad
        else -> C.primary
    }
    val base = when (kind) {
        0 -> shape(C.primary, 12)
        1 -> shape(Color.WHITE, 12, C.primary)
        2 -> shape(Color.WHITE, 12, Color.parseColor("#FCA5A5"))
        else -> shape(C.soft, 12)
    }
    row.background = ripple(base, 12)
    row.setPadding(dp(16), 0, dp(16), 0)
    row.minimumHeight = dp(48)
    if (iconRes != 0) {
        row.addView(icon(iconRes, fg, 20), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(8) })
    }
    row.addView(label(t, 15f, fg, true))
    row.isClickable = true
    row.setOnClickListener { onClick() }
    return row
}

fun Context.field(hint: String, kind: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
    this.hint = hint
    inputType = kind
    textSize = 15f
    setTextColor(C.text)
    setHintTextColor(C.muted)
    background = shape(Color.WHITE, 12, C.line)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    setSingleLine()
}

/** Round icon button (used on top of the map). */
fun Context.fab(res: Int, tint: Int = C.primary, onClick: () -> Unit): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    val p = dp(11)
    setPadding(p, p, p, p)
    background = shape(Color.WHITE, 24)
    elevation = dp(3).toFloat()
    isClickable = true
    setOnClickListener { onClick() }
}

/** Search box with a magnifier icon. Returns the container; the EditText is in [edit]. */
class SearchBox(ctx: Context, hint: String) {
    val edit: EditText = EditText(ctx)
    val root: LinearLayout = ctx.hbox()

    init {
        root.background = ctx.shape(Color.WHITE, 14, C.line)
        root.setPadding(ctx.dp(12), 0, ctx.dp(6), 0)
        root.addView(ctx.icon(R.drawable.ic_search, C.muted, 20))
        edit.hint = hint
        edit.textSize = 15f
        edit.setTextColor(C.text)
        edit.setHintTextColor(C.muted)
        edit.background = null
        edit.setSingleLine()
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.setPadding(ctx.dp(10), ctx.dp(13), ctx.dp(10), ctx.dp(13))
        root.addView(edit, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = ctx.icon(R.drawable.ic_close, C.muted, 18)
        clear.setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        clear.layoutParams = LinearLayout.LayoutParams(ctx.dp(32), ctx.dp(32))
        clear.setOnClickListener { edit.setText("") }
        root.addView(clear)
    }
}

/** Gradient header. [sub] can be updated later. */
class Header(ctx: Context, title: String, subText: String = "", onBack: (() -> Unit)? = null) {
    val root: LinearLayout = ctx.hbox()
    val sub: TextView = ctx.label(subText, 12f, Color.parseColor("#CFE0FF"))
    val title: TextView = ctx.label(title, 20f, Color.WHITE, true)
    val actions: LinearLayout = ctx.hbox()

    init {
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.dark, C.primary))
        root.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(12), ctx.dp(14))
        if (onBack != null) {
            val b = ctx.icon(R.drawable.ic_back, Color.WHITE, 24)
            b.setOnClickListener { onBack() }
            root.addView(b, LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)).apply { rightMargin = ctx.dp(12) })
        }
        val col = ctx.vbox()
        col.addView(this.title)
        col.addView(sub)
        root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(actions)
    }

    fun action(ctx: Context, res: Int, onClick: () -> Unit): ImageView {
        val v = ctx.icon(res, Color.WHITE, 22)
        v.setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        v.layoutParams = LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40))
        v.setOnClickListener { onClick() }
        actions.addView(v)
        return v
    }
}

fun Context.toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

fun View.gone(g: Boolean) {
    visibility = if (g) View.GONE else View.VISIBLE
}
